const jsonData = [
    {
        "ID": 1,
        "Extracts": "NSW Health is changing how it does things to meet challenges. They're putting in a big program to fix clinical, corporate, and tech stuff. Getting the right IT tools is key to making sure these changes last. Before, they had a mess of different systems which made things harder and more expensive. Plus, some of their systems are ancient and hard to support",
        "Wrapper": [
            {
                "Sub Groups": [
                    "Responsive Support",
                    "Process optimization"
                ],
                "Catergories": [
                    "Performance Tuning",
                    "Application Categorization"
                ],
                "Groups": [
                    "System Maintenance and Support",
                    "Operational Effectiveness and Efficiency"
                ],
                "Sub Catergories": [
                    "Monitoring tools, system optimization software, load balancers.",
                    "Metadata repositories, CMDB systems, and application portfolio management tools."
                ],
                "Factors": [
                    "Performance monitoring",
                    "Process efficiency"
                ]
            }
        ]
    },
    {
        "ID": 2,
        "Extracts": "Because of all this, it's hard to share patient info and coordinate care properly. Managers struggle to get accurate info on how well the systems are doing. And keeping them running costs a lot of money.",
        "Wrapper": [
            {
                "Sub Groups": [
                    "Regulatory adherence"
                ],
                "Catergories": [
                    "System Architecture"
                ],
                "Groups": [
                    "Compliance and Governance"
                ],
                "Sub Catergories": [
                    "Cloud platforms, microservices, network topology management."
                ],
                "Factors": [
                    "System interoperability"
                ]
            }
        ]
    },
    {
        "ID": 3,
        "Extracts": "This setup could harm the long-term success of the Clinical Services Redesign and Corporate Shared Services. So, they're reshaping the ICT program to fit these reforms better. They're aiming to connect scattered information and tech and quickly support both clinical and corporate changes.",
        "Wrapper": [
            {
                "Sub Groups": [
                    "Consistent Excellence",
                    "Responsive Support",
                    "Reliable Implementation"
                ],
                "Catergories": [
                    "Standards Adherence",
                    "Risk and Opportunity Analysis",
                    "Change Initiatives"
                ],
                "Groups": [
                    "Standardization and Streamlining Processes",
                    "System Maintenance and Support",
                    "System Deployment and Integration"
                ],
                "Sub Catergories": [
                    "Code quality tools, compliance software, audit management systems.",
                    "Risk management platforms, SWOT analysis tools, scenario planning software.",
                    "Change management software, communication platforms, project tracking tools."
                ],
                "Factors": [
                    "System compatibility",
                    "System maintenance",
                    "Integration capabilities"
                ]
            }
        ]
    },
    {
        "ID": 4,
        "Extracts": "Back in 2000, the Integrated Clinical Information Program (ICIP) started based on advice from the NSW Health Council. Its goal is to fix the problems with a clear plan. The idea is to give essential clinical features to all of NSW. They've already made big strides in setting up patient administration, clinical, and corporate systems",
        "Wrapper": [
            {
                "Sub Groups": [
                    "Strategic Cohesion",
                    "Process optimization",
                    "Reliable Implementation",
                    "Governance with Integrity",
                    "Regulatory adherence"
                ],
                "Catergories": [
                    "Policy & Regulation",
                    "Application Categorization",
                    "Change Initiatives",
                    "Policy Alignment",
                    "Outcome Measurement"
                ],
                "Groups": [
                    "Business Alignment",
                    "Operational Effectiveness and Efficiency",
                    "System Deployment and Integration",
                    "Policy and Organizational Reform",
                    "Compliance and Governance"
                ],
                "Sub Catergories": [
                    "Compliance management systems, policy repositories, audit tools.",
                    "Metadata repositories, CMDB systems, and application portfolio management tools.",
                    "Change management software, communication platforms, project tracking tools.",
                    "Strategy mapping software, governance frameworks, collaboration platforms.",
                    "KPI tracking tools, performance dashboards, data visualization software."
                ],
                "Factors": [
                    "Strategic alignment",
                    "Process efficiency",
                    "Integration capabilities",
                    "Sustainability initiatives",
                    "Compliance & regulations"
                ]
            }
        ]
    },
    {
        "ID": 5,
        "Extracts": "Clinical Systems Strategy\nCorporate Systems Strategy\nBusiness Information Strategy\nSustainable Infrastructure Strategy\nWhole of Government ICT Strategic Directions",
        "Wrapper": [
            {
                "Sub Groups": [
                    "Data governance",
                    "Process optimization",
                    "Process optimization"
                ],
                "Catergories": [
                    "Benefits Management Framework",
                    "Process Optimization",
                    "Integrated Service Design"
                ],
                "Groups": [
                    "Data and Information Management",
                    "Operational Effectiveness and Efficiency",
                    "Operational Effectiveness and Efficiency"
                ],
                "Sub Catergories": [
                    "Performance tracking software, KPI dashboards, and financial modeling tools.",
                    "Workflow engines, automation platforms, process mining tools.",
                    "Service design software, cross-system integration platforms, user journey mapping tools."
                ],
                "Factors": [
                    "Information flow",
                    "Standardization",
                    "User-centric optimization"
                ]
            }
        ]
    },
    {
        "ID": 6,
        "Extracts": "They're making care safer and better by giving clinicians the info they need and setting up systems for consistent, predictable processes across the state.",
        "Wrapper": [
            {
                "Sub Groups": [
                    "Teamwork enhancement",
                    "Reliable Implementation",
                    "Data governance"
                ],
                "Catergories": [
                    "Reporting Systems",
                    "Change Initiatives",
                    "Benefits Management Framework"
                ],
                "Groups": [
                    "Collaboration and Communication",
                    "System Deployment and Integration",
                    "Data and Information Management"
                ],
                "Sub Catergories": [
                    "Business intelligence platforms, dashboard software, data visualization tools.",
                    "Change management software, communication platforms, project tracking tools.",
                    "Performance tracking software, KPI dashboards, and financial modeling tools."
                ],
                "Factors": [
                    "Collaboration & teamwork",
                    "Integration capabilities",
                    "Information flow"
                ]
            }
        ]
    },
    {
        "ID": 7,
        "Extracts": "They're improving teamwork among health agencies in NSW, as well as with private companies and nationally, so everyone can work together better. This means info flows more smoothly, helping patients and making things more efficient.",
        "Wrapper": [
            {
                "Sub Groups": [
                    "Process optimization",
                    "Reliable Implementation",
                    "Governance with Integrity",
                    "Employee development"
                ],
                "Catergories": [
                    "Application Categorization",
                    "Dev Standards",
                    "Policy Alignment",
                    "Results-Based Planning"
                ],
                "Groups": [
                    "Operational Effectiveness and Efficiency",
                    "System Deployment and Integration",
                    "Policy and Organizational Reform",
                    "Employee Training and Development"
                ],
                "Sub Catergories": [
                    "Metadata repositories, CMDB systems, and application portfolio management tools.",
                    "Coding standards enforcement tools, static analysis, version control systems.",
                    "Strategy mapping software, governance frameworks, collaboration platforms.",
                    "Performance management software, strategic planning tools, reporting dashboards."
                ],
                "Factors": [
                    "Process efficiency",
                    "System deployment",
                    "Sustainability initiatives",
                    "Employee training"
                ]
            }
        ]
    },
    {
        "ID": 8,
        "Extracts": "They're expecting to save a lot of money by setting up new structures and ways of doing things. By rolling out key programs quickly, they'll spend less on managing projects, and they can piggyback on existing changes to save even more. This also means less disruption for clinicians and patients and less money spent on training.",
        "Wrapper": [
            {
                "Sub Groups": [
                    "Customer service",
                    "Strategic Cohesion",
                    "Budget control"
                ],
                "Catergories": [
                    "Helpdesk / User Services",
                    "Policy & Regulation",
                    "Resource Management"
                ],
                "Groups": [
                    "Consumer Experience and Support",
                    "Business Alignment",
                    "Financial Management and Budgeting"
                ],
                "Sub Catergories": [
                    "Ticketing systems, knowledge bases, live chat and call center software.",
                    "Compliance management systems, policy repositories, audit tools.",
                    "Workforce management software, budgeting tools, project tracking systems."
                ],
                "Factors": [
                    "User support",
                    "Strategic alignment",
                    "Funding & cost control"
                ]
            }
        ]
    },
    {
        "ID": 9,
        "Extracts": "The ICT Strategy is built on three main ideas:\nBetter support for clinicians and patient care.\nAligning with big NSW Health plans.\nSaving a lot of money.\n\nThese ideas guide five key objectives:\nUsing ICT to drive big changes in clinical care.\nCutting down on duplicated admin systems and costs.\nProviding top-notch info to everyone in the organization.\nSetting up a flexible ICT system that supports both clinical and corporate reforms.\nManaging ICT in a smart, coordinated way to get the most out of the investment.",
        "Wrapper": [
            {
                "Sub Groups": [
                    "Strategic Cohesion",
                    "Governance with Integrity",
                    "Budget control",
                    "Strategic Cohesion"
                ],
                "Catergories": [
                    "Policy & Regulation",
                    "Governance",
                    "Strategic Planning",
                    "Data Quality"
                ],
                "Groups": [
                    "Business Alignment",
                    "Policy and Organizational Reform",
                    "Financial Management and Budgeting",
                    "Business Alignment"
                ],
                "Sub Catergories": [
                    "Compliance management systems, policy repositories, audit tools.",
                    "Policy management systems, compliance tracking, audit management tools.",
                    "Roadmapping tools, portfolio management software, scenario analysis tools.",
                    "Data cleansing tools, validation software, profiling and monitoring tools."
                ],
                "Factors": [
                    "Strategic alignment",
                    "Policy & governance reform",
                    "Investment planning",
                    "Business reform & strategy"
                ]
            }
        ]
    },
    {
        "ID": 10,
        "Extracts": "ICT Asset Management Strategy\nNSW Health's Enterprise Architecture, which covers:\nClinical Systems Architecture\nCorporate Systems Architecture and Strategy\nBusiness Information Strategy\nInfrastructure Strategy\nIntegration Architecture Strategy\nICT Governance Framework\nICT Portfolio Management and Program of Work\nICT Investment Plan for 2006-2017.",
        "Wrapper": [
            {
                "Sub Groups": [
                    "Strategic Cohesion",
                    "Accountable Risk Management",
                    "Strategic Project Leadership"
                ],
                "Catergories": [
                    "Policy & Regulation",
                    "Joint Program Delivery",
                    "Stakeholder Engagement"
                ],
                "Groups": [
                    "Business Alignment",
                    "Risk Identification and Management",
                    "Program and Project Management"
                ],
                "Sub Catergories": [
                    "Compliance management systems, policy repositories, audit tools.",
                    "Collaborative project management tools, communication platforms, shared resource pools.",
                    "Collaboration platforms, survey software, communication tools."
                ],
                "Factors": [
                    "Strategic alignment",
                    "Risk identification & mitigation",
                    "Project prioritization"
                ]
            }
        ]
    },
    {
        "ID": 11,
        "Extracts": "From the RSP:\nThey've picked out results and services that rely on ICT assets.\nThey've identified risks related to ICT assets that could affect service delivery.\nThey've pinpointed services and measures that hinge on ICT assets working properly.\n\nFrom the NSW Health Corporate Plan:\nThey've considered the overall vision for the community.\nThey've outlined how NSW Health will contribute to this vision.\nThey've focused on strategies to achieve goals, along with potential risks.\nThey've set up ways to measure performance and ensure targets are met.\nThey've looked at the costs involved in reaching the vision and meeting targets.",
        "Wrapper": [
            {
                "Sub Groups": [
                    "Responsive Support"
                ],
                "Catergories": [
                    "Performance Tuning"
                ],
                "Groups": [
                    "System Maintenance and Support"
                ],
                "Sub Catergories": [
                    "Monitoring tools, system optimization software, load balancers."
                ],
                "Factors": [
                    "Performance monitoring"
                ]
            }
        ]
    },
    {
        "ID": 12,
        "Extracts": "    Contribution to major service reform agendas and alignment with planned NSW Health priorities and plans.\n    Support for the patient journey across different care settings and improvement of healthcare quality and safety for a large number of people.\n    Ability to enhance efficiency and effectiveness in healthcare delivery and workforce utilization.\n    Adherence to state ICT strategic planning requirements.\n    Potential to generate a positive return on investment.",
        "Wrapper": [
            {
                "Sub Groups": [
                    "Data governance",
                    "Strategic Project Leadership",
                    "Budget control"
                ],
                "Catergories": [
                    "Organizational Value",
                    "Process Standardization",
                    "Strategic Planning"
                ],
                "Groups": [
                    "Data and Information Management",
                    "Program and Project Management",
                    "Financial Management and Budgeting"
                ],
                "Sub Catergories": [
                    "Performance measurement systems, value tracking tools, business intelligence.",
                    "SOP management software, compliance tools, training platforms.",
                    "Roadmapping tools, portfolio management software, scenario analysis tools."
                ],
                "Factors": [
                    "Inclusion & equity",
                    "Scope management",
                    "Investment planning"
                ]
            }
        ]
    },
    {
        "ID": 13,
        "Extracts": "They should only add new projects to their investment plan. When it's time to replace old systems, they can handle it through contracts with vendors.",
        "Wrapper": [
            {
                "Sub Groups": [
                    "Strategic Project Leadership",
                    "Reliable Implementation",
                    "Customer service",
                    "Responsive Support"
                ],
                "Catergories": [
                    "Stakeholder Engagement",
                    "Dev Standards",
                    "Helpdesk / User Services",
                    "Performance Tuning"
                ],
                "Groups": [
                    "Program and Project Management",
                    "System Deployment and Integration",
                    "Consumer Experience and Support",
                    "System Maintenance and Support"
                ],
                "Sub Catergories": [
                    "Collaboration platforms, survey software, communication tools.",
                    "Coding standards enforcement tools, static analysis, version control systems.",
                    "Ticketing systems, knowledge bases, live chat and call center software.",
                    "Monitoring tools, system optimization software, load balancers."
                ],
                "Factors": [
                    "Project prioritization",
                    "System deployment",
                    "User support",
                    "Performance monitoring"
                ]
            }
        ]
    },
    {
        "ID": 14,
        "Extracts": "By 2011, they plan to have core clinical and corporate systems set up across NSW. This will help patients move through the healthcare system smoothly and ensure efficient management. Implementing the ICT Strategy will bring benefits to patients, clinicians, departments, hospitals, areas, and the whole state.",
        "Wrapper": [
            {
                "Sub Groups": [
                    "Teamwork enhancement",
                    "Customer service",
                    "Responsive Support"
                ],
                "Catergories": [
                    "Reporting Systems",
                    "Helpdesk / User Services",
                    "Capital Planning"
                ],
                "Groups": [
                    "Collaboration and Communication",
                    "Consumer Experience and Support",
                    "System Maintenance and Support"
                ],
                "Sub Catergories": [
                    "Business intelligence platforms, dashboard software, data visualization tools.",
                    "Ticketing systems, knowledge bases, live chat and call center software.",
                    "Financial planning software, ERP systems, investment portfolio management tools."
                ],
                "Factors": [
                    "Collaboration & teamwork",
                    "User support",
                    "Workforce sustainability"
                ]
            }
        ]
    },
    {
        "ID": 15,
        "Extracts": "For patients and clinicians, the goal is to have a complete picture of the patient's health history. This way, all healthcare providers can work together effectively, knowing each other's roles and contributions. Corporate systems also support this by giving a clear view of employees, making sure care is delivered smoothly",
        "Wrapper": [
            {
                "Sub Groups": [
                    "Process optimization",
                    "Customer service",
                    "Process optimization"
                ],
                "Catergories": [
                    "Integrated Service Design",
                    "System Interoperability",
                    "Application Categorization"
                ],
                "Groups": [
                    "Operational Effectiveness and Efficiency",
                    "Consumer Experience and Support",
                    "Operational Effectiveness and Efficiency"
                ],
                "Sub Catergories": [
                    "Service design software, cross-system integration platforms, user journey mapping tools.",
                    "Standard protocols (SOAP, REST), API management, messaging queues.",
                    "Metadata repositories, CMDB systems, and application portfolio management tools."
                ],
                "Factors": [
                    "User-centric optimization",
                    "Service accessibility",
                    "Process efficiency"
                ]
            }
        ]
    },
    {
        "ID": 16,
        "Extracts": "The strategy benefits patients by ensuring clinicians have all the information they need for optimal care, easily accessible whenever and wherever it's needed. This saves clinicians time by reducing the need to search for information or repeat tests unnecessarily, giving them more time for direct patient care.",
        "Wrapper": [
            {
                "Sub Groups": [
                    "Strategic Cohesion",
                    "Process optimization",
                    "Futureproofing"
                ],
                "Catergories": [
                    "Governance Structure",
                    "Application Categorization",
                    "Service Design"
                ],
                "Groups": [
                    "Business Alignment",
                    "Operational Effectiveness and Efficiency",
                    "Future Planning and System Demand"
                ],
                "Sub Catergories": [
                    "Organizational chart software, collaboration platforms, communication channels.",
                    "Metadata repositories, CMDB systems, and application portfolio management tools.",
                    "UX/UI design tools, service blueprinting software, customer journey mapping."
                ],
                "Factors": [
                    "Resource allocation",
                    "Process efficiency",
                    "Future system planning"
                ]
            }
        ]
    },
    {
        "ID": 17,
        "Extracts": "Nursing Unit Manager (NUM) can plan patient care better when they know all the demands and resources. This includes patients from the emergency room, post-surgery, and transfers, as well as available beds and staff skills.",
        "Wrapper": [
            {
                "Sub Groups": [
                    "Responsive Support",
                    "Strategic Cohesion",
                    "Budget control"
                ],
                "Catergories": [
                    "Performance Tuning",
                    "Governance Structure",
                    "Resource Management"
                ],
                "Groups": [
                    "System Maintenance and Support",
                    "Business Alignment",
                    "Financial Management and Budgeting"
                ],
                "Sub Catergories": [
                    "Monitoring tools, system optimization software, load balancers.",
                    "Organizational chart software, collaboration platforms, communication channels.",
                    "Workforce management software, budgeting tools, project tracking systems."
                ],
                "Factors": [
                    "Performance monitoring",
                    "Resource allocation",
                    "Funding & cost control"
                ]
            }
        ]
    },
    {
        "ID": 18,
        "Extracts": "At hospital, area, and department executive levels, having a complete portfolio lets them look at health outcomes, service demand, resources, performance, and finances all together.",
        "Wrapper": [
            {
                "Sub Groups": [
                    "Strategic Project Leadership",
                    "Strategic Cohesion",
                    "Process optimization"
                ],
                "Catergories": [
                    "Stakeholder Engagement",
                    "Governance Structure",
                    "Integration Architecture"
                ],
                "Groups": [
                    "Program and Project Management",
                    "Business Alignment",
                    "Operational Effectiveness and Efficiency"
                ],
                "Sub Catergories": [
                    "Collaboration platforms, survey software, communication tools.",
                    "Organizational chart software, collaboration platforms, communication channels.",
                    "API gateways, ESB, microservices architecture, message brokers."
                ],
                "Factors": [
                    "Project prioritization",
                    "Resource allocation",
                    "Service delivery"
                ]
            }
        ]
    },
    {
        "ID": 19,
        "Extracts": "The ICT Strategy focuses on key areas and will address them as resources allow. Other initiatives will only be added if they don't affect these core functions or if there's an urgent need.",
        "Wrapper": [
            {
                "Sub Groups": [
                    "Process optimization",
                    "Process optimization",
                    "Strategic Cohesion",
                    "Customer service"
                ],
                "Catergories": [
                    "Application Categorization",
                    "Integrated Service Design",
                    "Governance Structure",
                    "System Interoperability"
                ],
                "Groups": [
                    "Operational Effectiveness and Efficiency",
                    "Operational Effectiveness and Efficiency",
                    "Business Alignment",
                    "Consumer Experience and Support"
                ],
                "Sub Catergories": [
                    "Metadata repositories, CMDB systems, and application portfolio management tools.",
                    "Service design software, cross-system integration platforms, user journey mapping tools.",
                    "Organizational chart software, collaboration platforms, communication channels.",
                    "Standard protocols (SOAP, REST), API management, messaging queues."
                ],
                "Factors": [
                    "Process efficiency",
                    "User-centric optimization",
                    "Resource allocation",
                    "Service accessibility"
                ]
            }
        ]
    },
    {
        "ID": 20,
        "Extracts": "By 2011, clinical departments will have improved systems for workflow, decision-making support, and accessing necessary information. This helps clinicians make better decisions for patients, leading to safer care",
        "Wrapper": [
            {
                "Sub Groups": [
                    "Regulatory adherence",
                    "Customer service",
                    "Strategic Cohesion"
                ],
                "Catergories": [
                    "System Architecture",
                    "System Interoperability",
                    "Governance Structure"
                ],
                "Groups": [
                    "Compliance and Governance",
                    "Consumer Experience and Support",
                    "Business Alignment"
                ],
                "Sub Catergories": [
                    "Cloud platforms, microservices, network topology management.",
                    "Standard protocols (SOAP, REST), API management, messaging queues.",
                    "Organizational chart software, collaboration platforms, communication channels."
                ],
                "Factors": [
                    "System interoperability",
                    "Service accessibility",
                    "Resource allocation"
                ]
            }
        ]
    },
    {
        "ID": 21,
        "Extracts": "Integrated hospital systems mean information is collected once and available to all, reducing handover issues and improving resource management for smoother patient care.",
        "Wrapper": [
            {
                "Sub Groups": [
                    "Reliable Implementation",
                    "Customer service",
                    "Strategic Cohesion",
                    "Process optimization",
                    "Teamwork enhancement"
                ],
                "Catergories": [
                    "Change Initiatives",
                    "System Interoperability",
                    "Governance Structure",
                    "Process Optimization",
                    "Reporting Systems"
                ],
                "Groups": [
                    "System Deployment and Integration",
                    "Consumer Experience and Support",
                    "Business Alignment",
                    "Operational Effectiveness and Efficiency",
                    "Collaboration and Communication"
                ],
                "Sub Catergories": [
                    "Change management software, communication platforms, project tracking tools.",
                    "Standard protocols (SOAP, REST), API management, messaging queues.",
                    "Organizational chart software, collaboration platforms, communication channels.",
                    "Workflow engines, automation platforms, process mining tools.",
                    "Business intelligence platforms, dashboard software, data visualization tools."
                ],
                "Factors": [
                    "Integration capabilities",
                    "Service accessibility",
                    "Resource allocation",
                    "Standardization",
                    "Collaboration & teamwork"
                ]
            }
        ]
    },
    {
        "ID": 22,
        "Extracts": "The ICT Strategy aims to improve patient care by giving Nursing Unit Managers better information to plan and care for patients, helping hospital executives manage resources and performance, making it easier for departments to access important info and make decisions, integrating key systems across hospitals for smoother patient care, and standardizing information across regions to manage resources and patient transfers more effectively",
        "Wrapper": [
            {
                "Sub Groups": [
                    "Reliable Implementation",
                    "Process optimization",
                    "Strategic Cohesion",
                    "Futureproofing"
                ],
                "Catergories": [
                    "Dev Standards",
                    "Process Optimization",
                    "Governance Structure",
                    "Service Design"
                ],
                "Groups": [
                    "System Deployment and Integration",
                    "Operational Effectiveness and Efficiency",
                    "Business Alignment",
                    "Future Planning and System Demand"
                ],
                "Sub Catergories": [
                    "Coding standards enforcement tools, static analysis, version control systems.",
                    "Workflow engines, automation platforms, process mining tools.",
                    "Organizational chart software, collaboration platforms, communication channels.",
                    "UX/UI design tools, service blueprinting software, customer journey mapping."
                ],
                "Factors": [
                    "System deployment",
                    "Standardization",
                    "Resource allocation",
                    "Future system planning"
                ]
            }
        ]
    },
    {
        "ID": 23,
        "Extracts": "Rolling out core systems across NSW will have big benefits. Everyone gains, but it's best when the whole state uses them. Standardized info will help NSW Health meet goals by improving patient care, ensuring timely access to services, and better coordination in the health system. Accurate data will help use resources better and manage future needs.",
        "Wrapper": [
            {
                "Sub Groups": [
                    "Process optimization",
                    "Responsive Support",
                    "Futureproofing"
                ],
                "Catergories": [
                    "Integration Architecture",
                    "Performance Tuning",
                    "Service Design"
                ],
                "Groups": [
                    "Operational Effectiveness and Efficiency",
                    "System Maintenance and Support",
                    "Future Planning and System Demand"
                ],
                "Sub Catergories": [
                    "API gateways, ESB, microservices architecture, message brokers.",
                    "Monitoring tools, system optimization software, load balancers.",
                    "UX/UI design tools, service blueprinting software, customer journey mapping."
                ],
                "Factors": [
                    "Service delivery",
                    "Performance monitoring",
                    "Future system planning"
                ]
            }
        ]
    },
    {
        "ID": 24,
        "Extracts": "A steady increase in demand for services is expected due to an aging population. In NSW, the number of people over 65 is growing quickly. Each year from 2012 to 2028, the percentage of older Australians is projected to rise by over 0.35 points annually, which is about four times the long-term average increase.",
        "Wrapper": [
            {
                "Sub Groups": [
                    "Responsive Support",
                    "Accountable Risk Management",
                    "Strategic Cohesion"
                ],
                "Catergories": [
                    "Capital Planning",
                    "Joint Program Delivery",
                    "Governance Structure"
                ],
                "Groups": [
                    "System Maintenance and Support",
                    "Risk Identification and Management",
                    "Business Alignment"
                ],
                "Sub Catergories": [
                    "Financial planning software, ERP systems, investment portfolio management tools.",
                    "Collaborative project management tools, communication platforms, shared resource pools.",
                    "Organizational chart software, collaboration platforms, communication channels."
                ],
                "Factors": [
                    "Workforce sustainability",
                    "Risk identification & mitigation",
                    "Resource allocation"
                ]
            }
        ]
    },
    {
        "ID": 25,
        "Extracts": "Staff shortages in critical areas such as nursing and medicine Hospitals running at maximum capacity",
        "Wrapper": [
            {
                "Sub Groups": [
                    "Data governance",
                    "Responsive Support",
                    "Futureproofing"
                ],
                "Catergories": [
                    "Policy Compliance",
                    "Performance Tuning",
                    "Service Design"
                ],
                "Groups": [
                    "Data and Information Management",
                    "System Maintenance and Support",
                    "Future Planning and System Demand"
                ],
                "Sub Catergories": [
                    "Automated compliance monitoring, reporting systems, risk assessment tools.",
                    "Monitoring tools, system optimization software, load balancers.",
                    "UX/UI design tools, service blueprinting software, customer journey mapping."
                ],
                "Factors": [
                    "Data management",
                    "Performance monitoring",
                    "Future system planning"
                ]
            }
        ]
    },
    {
        "ID": 26,
        "Extracts": "The rate of chronic diseases like heart disease, lung disease, diabetes, and cancer is rising. Obesity is becoming more common among young people, and our increasingly globalized society raises the risk of pandemics.",
        "Wrapper": [
            {
                "Sub Groups": [
                    "Data governance",
                    "Innovative Evolution"
                ],
                "Catergories": [
                    "Change Readiness",
                    "Budget Constraint Handling"
                ],
                "Groups": [
                    "Data and Information Management",
                    "System and Technology Improvement"
                ],
                "Sub Catergories": [
                    "Readiness assessment tools, survey platforms, stakeholder engagement systems.",
                    "Financial planning software, cost tracking systems, and resource allocation platforms."
                ],
                "Factors": [
                    "Knowledge & content management",
                    "Technology advancement"
                ]
            }
        ]
    },
    {
        "ID": 27,
        "Extracts": "An increasing body of medical knowledge that staff cannot manage and\nuse without advanced IT systems",
        "Wrapper": [
            {
                "Sub Groups": [
                    "Budget control",
                    "Innovative Evolution"
                ],
                "Catergories": [
                    "Resource Management",
                    "Budget Constraint Handling"
                ],
                "Groups": [
                    "Financial Management and Budgeting",
                    "System and Technology Improvement"
                ],
                "Sub Catergories": [
                    "Workforce management software, budgeting tools, project tracking systems.",
                    "Financial planning software, cost tracking systems, and resource allocation platforms."
                ],
                "Factors": [
                    "Funding & cost control",
                    "Technology advancement"
                ]
            }
        ]
    },
    {
        "ID": 28,
        "Extracts": "Health services are increasingly challenged by more expensive medical technologies and pharmaceuticals",
        "Wrapper": [
            {
                "Sub Groups": [
                    "Customer service",
                    "Process optimization",
                    "Accountable Risk Management"
                ],
                "Catergories": [
                    "Strategic Planning",
                    "Integration Architecture",
                    "Service Availability"
                ],
                "Groups": [
                    "Consumer Experience and Support",
                    "Operational Effectiveness and Efficiency",
                    "Risk Identification and Management"
                ],
                "Sub Catergories": [
                    "Roadmapping tools, portfolio management software, scenario analysis tools.",
                    "API gateways, ESB, microservices architecture, message brokers.",
                    "Monitoring systems, failover infrastructure, SLA tracking software."
                ],
                "Factors": [
                    "Consumer experience",
                    "Service delivery",
                    "High-risk environment"
                ]
            }
        ]
    },
    {
        "ID": 29,
        "Extracts": "Consumers are becoming more informed, have higher expectations and more complex problems",
        "Wrapper": [
            {
                "Sub Groups": [
                    "Customer service",
                    "Process optimization",
                    "Accountable Risk Management"
                ],
                "Catergories": [
                    "Strategic Planning",
                    "Integration Architecture",
                    "Service Availability"
                ],
                "Groups": [
                    "Consumer Experience and Support",
                    "Operational Effectiveness and Efficiency",
                    "Risk Identification and Management"
                ],
                "Sub Catergories": [
                    "Roadmapping tools, portfolio management software, scenario analysis tools.",
                    "API gateways, ESB, microservices architecture, message brokers.",
                    "Monitoring systems, failover infrastructure, SLA tracking software."
                ],
                "Factors": [
                    "Consumer experience",
                    "Service delivery",
                    "High-risk environment"
                ]
            }
        ]
    },
    {
        "ID": 30,
        "Extracts": "Quality and safety standards are being challenged as demand increases and staff numbers decrease. For instance, from 2000 to 2005, NSW hospitals had an average occupancy of 93%. Some metropolitan hospitals had surgical and medical wards with 95-98% occupancy, while 85% is considered a much safer level.",
        "Wrapper": [
            {
                "Sub Groups": [
                    "Consistent Excellence",
                    "Governance with Integrity",
                    "Employee development",
                    "Responsive Support"
                ],
                "Catergories": [
                    "Strategic Alignment",
                    "Governance",
                    "Care Coordination Systems",
                    "Capital Planning"
                ],
                "Groups": [
                    "Standardization and Streamlining Processes",
                    "Policy and Organizational Reform",
                    "Employee Training and Development",
                    "System Maintenance and Support"
                ],
                "Sub Catergories": [
                    "Balanced scorecards, strategy mapping tools, performance management platforms.",
                    "Policy management systems, compliance tracking, audit management tools.",
                    "Patient management systems, health information exchanges, secure messaging platforms.",
                    "Financial planning software, ERP systems, investment portfolio management tools."
                ],
                "Factors": [
                    "Communication standards",
                    "Policy & governance reform",
                    "Skills development",
                    "Workforce sustainability"
                ]
            }
        ]
    },
    {
        "ID": 31,
        "Extracts": "The key factors that cause these adverse events are:\n_x0001_ Communication\n_x0001_ Policies and procedures\n_x0001_ Knowledge, skills and competence issues\n_x0001_ Work scheduling",
        "Wrapper": [
            {
                "Sub Groups": [
                    "Reliable Implementation",
                    "Strategic Cohesion"
                ],
                "Catergories": [
                    "Dev Standards",
                    "Data Quality"
                ],
                "Groups": [
                    "System Deployment and Integration",
                    "Business Alignment"
                ],
                "Sub Catergories": [
                    "Coding standards enforcement tools, static analysis, version control systems.",
                    "Data cleansing tools, validation software, profiling and monitoring tools."
                ],
                "Factors": [
                    "System deployment",
                    "Business reform & strategy"
                ]
            }
        ]
    },
    {
        "ID": 32,
        "Extracts": "Clinical ICT is becoming an increasingly important enabler of health\nsystem reform, yet the core systems to underpin reform are not\ncurrently in place.",
        "Wrapper": [
            {
                "Sub Groups": [
                    "Reliable Implementation"
                ],
                "Catergories": [
                    "Change Initiatives"
                ],
                "Groups": [
                    "System Deployment and Integration"
                ],
                "Sub Catergories": [
                    "Change management software, communication platforms, project tracking tools."
                ],
                "Factors": [
                    "Integration capabilities"
                ]
            }
        ]
    },
    {
        "ID": 33,
        "Extracts": "Constraints in capital and recurrent funding, skilled project\nmanagement and implementation resources and capacity of the health\nsystems to accommodate large scale change all restrict the potential\nspeed of implementation of core systems.",
        "Wrapper": [
            {
                "Sub Groups": [
                    "Budget control",
                    "Strategic Project Leadership",
                    "Responsive Support"
                ],
                "Catergories": [
                    "Resource Management",
                    "Budget Allocation Strategies",
                    "Capital Planning"
                ],
                "Groups": [
                    "Financial Management and Budgeting",
                    "Program and Project Management",
                    "System Maintenance and Support"
                ],
                "Sub Catergories": [
                    "Workforce management software, budgeting tools, project tracking systems.",
                    "ERP systems, budgeting modules, and portfolio management software.",
                    "Financial planning software, ERP systems, investment portfolio management tools."
                ],
                "Factors": [
                    "Funding & cost control",
                    "Skilled project execution",
                    "Workforce sustainability"
                ]
            }
        ]
    },
    {
        "ID": 34,
        "Extracts": "There are many competing demands for ICT funds. Deciding which projects to prioritize and schedule is complex and needs ongoing review to ensure funds are allocated where they will be most beneficial.",
        "Wrapper": [
            {
                "Sub Groups": [
                    "Budget control",
                    "Strategic Project Leadership",
                    "Strategic Project Leadership"
                ],
                "Catergories": [
                    "Resource Management",
                    "Stakeholder Engagement",
                    "Process Standardization"
                ],
                "Groups": [
                    "Financial Management and Budgeting",
                    "Program and Project Management",
                    "Program and Project Management"
                ],
                "Sub Catergories": [
                    "Workforce management software, budgeting tools, project tracking systems.",
                    "Collaboration platforms, survey software, communication tools.",
                    "SOP management software, compliance tools, training platforms."
                ],
                "Factors": [
                    "Funding & cost control",
                    "Project prioritization",
                    "Scope management"
                ]
            }
        ]
    },
    {
        "ID": 35,
        "Extracts": "NSW Health needs to change how it delivers services to meet these challenges. They've started a big reform program and need the right IT solutions to support staff and make these changes last",
        "Wrapper": [
            {
                "Sub Groups": [
                    "Accountable Risk Management",
                    "Accountable Risk Management",
                    "Process optimization"
                ],
                "Catergories": [
                    "Joint Program Delivery",
                    "Service Availability",
                    "Integration Architecture"
                ],
                "Groups": [
                    "Risk Identification and Management",
                    "Risk Identification and Management",
                    "Operational Effectiveness and Efficiency"
                ],
                "Sub Catergories": [
                    "Collaborative project management tools, communication platforms, shared resource pools.",
                    "Monitoring systems, failover infrastructure, SLA tracking software.",
                    "API gateways, ESB, microservices architecture, message brokers."
                ],
                "Factors": [
                    "Risk identification & mitigation",
                    "High-risk environment",
                    "Service delivery"
                ]
            }
        ]
    },
    {
        "ID": 36,
        "Extracts": "NSW Health is responding to big challenges like more people needing healthcare and not enough staff. They're looking at what the government wants, like improving mental health and using better technology. That helps them decide what to do next and where to spend money.",
        "Wrapper": [
            {
                "Sub Groups": [
                    "Process optimization",
                    "Responsive Support",
                    "Strategic Cohesion",
                    "Strategic Cohesion"
                ],
                "Catergories": [
                    "Integration Architecture",
                    "Capital Planning",
                    "Resource Optimization",
                    "Policy & Regulation"
                ],
                "Groups": [
                    "Operational Effectiveness and Efficiency",
                    "System Maintenance and Support",
                    "Business Alignment",
                    "Business Alignment"
                ],
                "Sub Catergories": [
                    "API gateways, ESB, microservices architecture, message brokers.",
                    "Financial planning software, ERP systems, investment portfolio management tools.",
                    "Automation tools, analytics platforms, load balancing systems.",
                    "Compliance management systems, policy repositories, audit tools."
                ],
                "Factors": [
                    "Service delivery",
                    "Workforce sustainability",
                    "Government priorities & guidelines",
                    "Strategic alignment"
                ]
            }
        ]
    },
    {
        "ID": 37,
        "Extracts": "The Results and Services Plan guides everything in NSW Health. There are other plans helping out too. The ICT Strategic Plan is one of them, making sure it works well with the main plan. They also look at what the whole government and the country are doing.",
        "Wrapper": [
            {
                "Sub Groups": [
                    "Strategic Cohesion",
                    "Governance with Integrity",
                    "Strategic Cohesion",
                    "Strategic Cohesion"
                ],
                "Catergories": [
                    "Policy & Regulation",
                    "Governance",
                    "Data Quality",
                    "Resource Optimization"
                ],
                "Groups": [
                    "Business Alignment",
                    "Policy and Organizational Reform",
                    "Business Alignment",
                    "Business Alignment"
                ],
                "Sub Catergories": [
                    "Compliance management systems, policy repositories, audit tools.",
                    "Policy management systems, compliance tracking, audit management tools.",
                    "Data cleansing tools, validation software, profiling and monitoring tools.",
                    "Automation tools, analytics platforms, load balancing systems."
                ],
                "Factors": [
                    "Strategic alignment",
                    "Policy & governance reform",
                    "Business reform & strategy",
                    "Government priorities & guidelines"
                ]
            }
        ]
    },
    {
        "ID": 38,
        "Extracts": "The RSP is NSW Health's main plan to tackle challenges. They have four main goals:\nKeep people healthy\nProvide needed healthcare\nDeliver top-quality services\nManage health services well\n\nTo achieve these, they focus on seven key directions:\nGet everyone involved in prevention\nImprove people's healthcare experiences\nStrengthen community care\nWork with others for better health\nMake wise choices about healthcare costs\nBuild a strong healthcare workforce\nStay prepared for new challenges and chances",
        "Wrapper": [
            {
                "Sub Groups": [
                    "Customer service",
                    "Futureproofing",
                    "Teamwork enhancement",
                    "Budget control",
                    "Responsive Support",
                    "Accountable Risk Management"
                ],
                "Catergories": [
                    "Strategic Planning",
                    "Service Design",
                    "Reporting Systems",
                    "Resource Management",
                    "Capital Planning",
                    "Joint Program Delivery"
                ],
                "Groups": [
                    "Consumer Experience and Support",
                    "Future Planning and System Demand",
                    "Collaboration and Communication",
                    "Financial Management and Budgeting",
                    "System Maintenance and Support",
                    "Risk Identification and Management"
                ],
                "Sub Catergories": [
                    "Roadmapping tools, portfolio management software, scenario analysis tools.",
                    "UX/UI design tools, service blueprinting software, customer journey mapping.",
                    "Business intelligence platforms, dashboard software, data visualization tools.",
                    "Workforce management software, budgeting tools, project tracking systems.",
                    "Financial planning software, ERP systems, investment portfolio management tools.",
                    "Collaborative project management tools, communication platforms, shared resource pools."
                ],
                "Factors": [
                    "Consumer experience",
                    "Future system planning",
                    "Collaboration & teamwork",
                    "Funding & cost control",
                    "Workforce sustainability",
                    "Risk identification & mitigation"
                ]
            }
        ]
    },
    {
        "ID": 39,
        "Extracts": "NSW Health wants to prevent sickness and promote good health habits. They're focusing on getting more people vaccinated and helping those at risk for diseases like diabetes. ICT can help by sending alerts about things like missed vaccinations or overdue check-ups",
        "Wrapper": [
            {
                "Sub Groups": [
                    "Accountable Risk Management",
                    "Customer service",
                    "Budget control"
                ],
                "Catergories": [
                    "Joint Program Delivery",
                    "Strategic Planning",
                    "Transition Planning"
                ],
                "Groups": [
                    "Risk Identification and Management",
                    "Consumer Experience and Support",
                    "Financial Management and Budgeting"
                ],
                "Sub Catergories": [
                    "Collaborative project management tools, communication platforms, shared resource pools.",
                    "Roadmapping tools, portfolio management software, scenario analysis tools.",
                    "Project scheduling, resource allocation software, stakeholder engagement platforms."
                ],
                "Factors": [
                    "Risk identification & mitigation",
                    "Consumer experience",
                    "Preventative solutions"
                ]
            }
        ]
    },
    {
        "ID": 40,
        "Extracts": "NSW Health wants to make sure everyone gets the care they need, when they need it. They're using tech to support new ways of caring for people and making sure changes stick. Better info during your care journey means a better experience and getting the right care.",
        "Wrapper": [
            {
                "Sub Groups": [
                    "Customer service",
                    "Process optimization",
                    "Teamwork enhancement",
                    "Governance with Integrity",
                    "Data governance",
                    "Customer service"
                ],
                "Catergories": [
                    "System Interoperability",
                    "Integration Architecture",
                    "Business Case Development",
                    "Policy Alignment",
                    "Benefits Management Framework",
                    "Strategic Planning"
                ],
                "Groups": [
                    "Consumer Experience and Support",
                    "Operational Effectiveness and Efficiency",
                    "Collaboration and Communication",
                    "Policy and Organizational Reform",
                    "Data and Information Management",
                    "Consumer Experience and Support"
                ],
                "Sub Catergories": [
                    "Standard protocols (SOAP, REST), API management, messaging queues.",
                    "API gateways, ESB, microservices architecture, message brokers.",
                    "Project management tools, ROI calculators, and collaboration platforms.",
                    "Strategy mapping software, governance frameworks, collaboration platforms.",
                    "Performance tracking software, KPI dashboards, and financial modeling tools.",
                    "Roadmapping tools, portfolio management software, scenario analysis tools."
                ],
                "Factors": [
                    "Service accessibility",
                    "Service delivery",
                    "Coordination & support",
                    "Sustainability initiatives",
                    "Information flow",
                    "Consumer experience"
                ]
            }
        ]
    },
    {
        "ID": 41,
        "Extracts": "NSW Health aims to improve healthcare by working better together. They're using tech to help everyone collaborate and use resources wisely. That means better tools for healthcare workers and making sure everyone gets great care.",
        "Wrapper": [
            {
                "Sub Groups": [
                    "Process optimization",
                    "Teamwork enhancement",
                    "Teamwork enhancement",
                    "Process optimization",
                    "Strategic Cohesion"
                ],
                "Catergories": [
                    "Application Categorization",
                    "Reporting Systems",
                    "Business Case Development",
                    "Interagency Cooperation",
                    "Governance Structure"
                ],
                "Groups": [
                    "Operational Effectiveness and Efficiency",
                    "Collaboration and Communication",
                    "Collaboration and Communication",
                    "Operational Effectiveness and Efficiency",
                    "Business Alignment"
                ],
                "Sub Catergories": [
                    "Metadata repositories, CMDB systems, and application portfolio management tools.",
                    "Business intelligence platforms, dashboard software, data visualization tools.",
                    "Project management tools, ROI calculators, and collaboration platforms.",
                    "Secure collaboration platforms, data sharing agreements, federation technologies.",
                    "Organizational chart software, collaboration platforms, communication channels."
                ],
                "Factors": [
                    "Process efficiency",
                    "Collaboration & teamwork",
                    "Coordination & support",
                    "Quality & safety",
                    "Resource allocation"
                ]
            }
        ]
    },
    {
        "ID": 42,
        "Extracts": "The NSW Government's IT setup influences NSW Health's ICT plan. They aim to make sure NSW initiatives match up with and sometimes even help shape national and statewide plans",
        "Wrapper": [
            {
                "Sub Groups": [
                    "Strategic Project Leadership",
                    "Strategic Cohesion"
                ],
                "Catergories": [
                    "Process Standardization",
                    "Policy & Regulation"
                ],
                "Groups": [
                    "Program and Project Management",
                    "Business Alignment"
                ],
                "Sub Catergories": [
                    "SOP management software, compliance tools, training platforms.",
                    "Compliance management systems, policy repositories, audit tools."
                ],
                "Factors": [
                    "Scope management",
                    "Strategic alignment"
                ]
            }
        ]
    },
    {
        "ID": 43,
        "Extracts": "The NSW Government is changing how they use computers and stuff. They want to save money on the boring tech stuff while keeping important services running smoothly. They're spending more on technology for important services and finding ways to save money with computers. This means using one fund for all tech needs, having a plan for the whole state, using fewer computer programs, sharing tech, and buying things together.",
        "Wrapper": [
            {
                "Sub Groups": [
                    "Innovative Evolution",
                    "Strategic Cohesion"
                ],
                "Catergories": [
                    "Budget Constraint Handling",
                    "Policy & Regulation"
                ],
                "Groups": [
                    "System and Technology Improvement",
                    "Business Alignment"
                ],
                "Sub Catergories": [
                    "Financial planning software, cost tracking systems, and resource allocation platforms.",
                    "Compliance management systems, policy repositories, audit tools."
                ],
                "Factors": [
                    "Technology advancement",
                    "Strategic alignment"
                ]
            }
        ]
    },
    {
        "ID": 44,
        "Extracts": "COAG is a group working on important national stuff like mental health, healthcare workers, flu plans, and electronic health records. They're making big plans for healthcare, like making hospitals better and helping people stay healthy. This ICT plan is part of making those plans work by improving healthcare in hospitals and communities",
        "Wrapper": [
            {
                "Sub Groups": [
                    "Data governance"
                ],
                "Catergories": [
                    "Change Management"
                ],
                "Groups": [
                    "Data and Information Management"
                ],
                "Sub Catergories": [
                    "Collaboration tools, training portals, feedback and adoption tracking systems."
                ],
                "Factors": [
                    "Data sharing & integration"
                ]
            }
        ]
    },
    {
        "ID": 45,
        "Extracts": "The eHealth initiative involves all states, territories, and the Australian Government. It began in 2000 to set up e-health across Australia. The Australian Government has invested $128 million in e-health projects across the country, plus an extra $10 million in 2005 for managed health network grants. The aim is to make sure everyone works together, with consistent approaches to eHealth, creating a national health information network. The program also helps make the right rules for eHealth initiatives.",
        "Wrapper": [
            {
                "Sub Groups": [
                    "Strategic Cohesion",
                    "Strategic Cohesion",
                    "Data governance",
                    "Budget control"
                ],
                "Catergories": [
                    "Resource Optimization",
                    "Data Quality",
                    "Organizational Value",
                    "Transition Planning"
                ],
                "Groups": [
                    "Business Alignment",
                    "Business Alignment",
                    "Data and Information Management",
                    "Financial Management and Budgeting"
                ],
                "Sub Catergories": [
                    "Automation tools, analytics platforms, load balancing systems.",
                    "Data cleansing tools, validation software, profiling and monitoring tools.",
                    "Performance measurement systems, value tracking tools, business intelligence.",
                    "Project scheduling, resource allocation software, stakeholder engagement platforms."
                ],
                "Factors": [
                    "Government priorities & guidelines",
                    "Business reform & strategy",
                    "Inclusion & equity",
                    "Preventative solutions"
                ]
            }
        ]
    },
    {
        "ID": 46,
        "Extracts": "focuses on developing national health information management and communication technology standards. Its work includes creating frameworks for interoperability, standardizing clinical communications, establishing unique healthcare identifiers, and preparing standards for individual electronic health records, identity management, secure messaging, and supply chain management.",
        "Wrapper": [
            {
                "Sub Groups": [
                    "Teamwork enhancement",
                    "Process optimization",
                    "Data governance",
                    "Regulatory adherence"
                ],
                "Catergories": [
                    "Reporting Systems",
                    "Process Optimization",
                    "Change Management",
                    "Outcome Measurement"
                ],
                "Groups": [
                    "Collaboration and Communication",
                    "Operational Effectiveness and Efficiency",
                    "Data and Information Management",
                    "Compliance and Governance"
                ],
                "Sub Catergories": [
                    "Business intelligence platforms, dashboard software, data visualization tools.",
                    "Workflow engines, automation platforms, process mining tools.",
                    "Collaboration tools, training portals, feedback and adoption tracking systems.",
                    "KPI tracking tools, performance dashboards, data visualization software."
                ],
                "Factors": [
                    "Collaboration & teamwork",
                    "Standardization",
                    "Data sharing & integration",
                    "Compliance & regulations"
                ]
            }
        ]
    },
    {
        "ID": 47,
        "Extracts": "To tackle challenges and prepare for the future, NSW Health is changing how it delivers services. Implementing IT solutions to support staff and integrate business processes is key for sustainable service delivery changes.",
        "Wrapper": [
            {
                "Sub Groups": [
                    "Regulatory adherence",
                    "Strategic Cohesion",
                    "Regulatory adherence",
                    "Process optimization",
                    "Data integrity",
                    "Data integrity"
                ],
                "Catergories": [
                    "Outcome Measurement",
                    "Policy & Regulation",
                    "System Architecture",
                    "Process Optimization",
                    "Program Governance",
                    "Communication Tools"
                ],
                "Groups": [
                    "Compliance and Governance",
                    "Business Alignment",
                    "Compliance and Governance",
                    "Operational Effectiveness and Efficiency",
                    "Data Security, Quality and Privacy",
                    "Data Security, Quality and Privacy"
                ],
                "Sub Catergories": [
                    "KPI tracking tools, performance dashboards, data visualization software.",
                    "Compliance management systems, policy repositories, audit tools.",
                    "Cloud platforms, microservices, network topology management.",
                    "Workflow engines, automation platforms, process mining tools.",
                    "Governance platforms, risk management tools, compliance dashboards.",
                    "Unified communications systems, VoIP, video conferencing platforms."
                ],
                "Factors": [
                    "Compliance & regulations",
                    "Strategic alignment",
                    "System interoperability",
                    "Standardization",
                    "Data integrity & privacy",
                    "Secure data practices"
                ]
            }
        ]
    },
    {
        "ID": 48,
        "Extracts": "NEHTA makes sure health info works the same way everywhere in Australia. They're working on stuff like making sure doctors' notes and patient info look the same everywhere. They're also setting up a single ID for healthcare and getting ready for a national health record system. Plus, they're making sure the stuff doctors send each other is safe, and helping with buying healthcare stuff",
        "Wrapper": [
            {
                "Sub Groups": [
                    "Strategic Cohesion",
                    "Budget control",
                    "Budget control",
                    "Strategic Project Leadership"
                ],
                "Catergories": [
                    "Policy & Regulation",
                    "Strategic Planning",
                    "Resource Management",
                    "Stakeholder Engagement"
                ],
                "Groups": [
                    "Business Alignment",
                    "Financial Management and Budgeting",
                    "Financial Management and Budgeting",
                    "Program and Project Management"
                ],
                "Sub Catergories": [
                    "Compliance management systems, policy repositories, audit tools.",
                    "Roadmapping tools, portfolio management software, scenario analysis tools.",
                    "Workforce management software, budgeting tools, project tracking systems.",
                    "Collaboration platforms, survey software, communication tools."
                ],
                "Factors": [
                    "Strategic alignment",
                    "Investment planning",
                    "Funding & cost control",
                    "Project prioritization"
                ]
            }
        ]
    },
    {
        "ID": 49,
        "Extracts": "Health Support Services sets up and maintains key computer systems for healthcare. They give specific IT help to Area Health Services as defined by the law. This includes managing computers, software, and helping with setting up systems.",
        "Wrapper": [
            {
                "Sub Groups": [
                    "Customer service",
                    "Reliable Implementation",
                    "Responsive Support"
                ],
                "Catergories": [
                    "Helpdesk / User Services",
                    "Dev Standards",
                    "Risk and Opportunity Analysis"
                ],
                "Groups": [
                    "Consumer Experience and Support",
                    "System Deployment and Integration",
                    "System Maintenance and Support"
                ],
                "Sub Catergories": [
                    "Ticketing systems, knowledge bases, live chat and call center software.",
                    "Coding standards enforcement tools, static analysis, version control systems.",
                    "Risk management platforms, SWOT analysis tools, scenario planning software."
                ],
                "Factors": [
                    "User support",
                    "System deployment",
                    "System maintenance"
                ]
            }
        ]
    },
    {
        "ID": 50,
        "Extracts": "Area Health Services are responsible for the management of local\nimplementations, change management and training of staff and benefits\nrealisation.",
        "Wrapper": [
            {
                "Sub Groups": [
                    "Process optimization",
                    "Reliable Implementation",
                    "Employee development",
                    "Strategic Cohesion"
                ],
                "Catergories": [
                    "Integration Architecture",
                    "Dev Standards",
                    "Care Coordination Systems",
                    "Data Management"
                ],
                "Groups": [
                    "Operational Effectiveness and Efficiency",
                    "System Deployment and Integration",
                    "Employee Training and Development",
                    "Business Alignment"
                ],
                "Sub Catergories": [
                    "API gateways, ESB, microservices architecture, message brokers.",
                    "Coding standards enforcement tools, static analysis, version control systems.",
                    "Patient management systems, health information exchanges, secure messaging platforms.",
                    "Database management systems, data lakes, cloud storage solutions."
                ],
                "Factors": [
                    "Service delivery",
                    "System deployment",
                    "Skills development",
                    "Benefit realization"
                ]
            }
        ]
    },
    {
        "ID": 51,
        "Extracts": "They pick the most important projects and invest wisely for the health system. We work together on ICT stuff and have clear rules. This helps us decide what to build and how to run things",
        "Wrapper": [
            {
                "Sub Groups": [
                    "Strategic Project Leadership",
                    "Budget control",
                    "Strategic Cohesion",
                    "Process optimization",
                    "Teamwork enhancement"
                ],
                "Catergories": [
                    "Stakeholder Engagement",
                    "Strategic Planning",
                    "Data Management",
                    "Process Optimization",
                    "Reporting Systems"
                ],
                "Groups": [
                    "Program and Project Management",
                    "Financial Management and Budgeting",
                    "Business Alignment",
                    "Operational Effectiveness and Efficiency",
                    "Collaboration and Communication"
                ],
                "Sub Catergories": [
                    "Collaboration platforms, survey software, communication tools.",
                    "Roadmapping tools, portfolio management software, scenario analysis tools.",
                    "Database management systems, data lakes, cloud storage solutions.",
                    "Workflow engines, automation platforms, process mining tools.",
                    "Business intelligence platforms, dashboard software, data visualization tools."
                ],
                "Factors": [
                    "Project prioritization",
                    "Investment planning",
                    "Benefit realization",
                    "Standardization",
                    "Collaboration & teamwork"
                ]
            }
        ]
    },
    {
        "ID": 52,
        "Extracts": "NSW Health uses a coordinated approach to manage ICT projects. This helps us evaluate, prioritize, select, and monitor programs and projects. We adjust as needed to meet our business goals.",
        "Wrapper": [
            {
                "Sub Groups": [
                    "Strategic Project Leadership",
                    "Responsive Support",
                    "Strategic Cohesion"
                ],
                "Catergories": [
                    "Stakeholder Engagement",
                    "Performance Tuning",
                    "Policy & Regulation"
                ],
                "Groups": [
                    "Program and Project Management",
                    "System Maintenance and Support",
                    "Business Alignment"
                ],
                "Sub Catergories": [
                    "Collaboration platforms, survey software, communication tools.",
                    "Monitoring tools, system optimization software, load balancers.",
                    "Compliance management systems, policy repositories, audit tools."
                ],
                "Factors": [
                    "Project prioritization",
                    "Performance monitoring",
                    "Strategic alignment"
                ]
            }
        ]
    },
    {
        "ID": 53,
        "Extracts": "They have set ways of doing things that support our ICT plan. These cover every step of a project's life.",
        "Wrapper": [
            {
                "Sub Groups": [
                    "Process optimization",
                    "Governance with Integrity"
                ],
                "Catergories": [
                    "Process Optimization",
                    "Governance"
                ],
                "Groups": [
                    "Operational Effectiveness and Efficiency",
                    "Policy and Organizational Reform"
                ],
                "Sub Catergories": [
                    "Workflow engines, automation platforms, process mining tools.",
                    "Policy management systems, compliance tracking, audit management tools."
                ],
                "Factors": [
                    "Standardization",
                    "Policy & governance reform"
                ]
            }
        ]
    },
    {
        "ID": 54,
        "Extracts": "To make the strategy work, NSW Health collaborates with the Department of Health, Area Health Services, Health Technology, and third-party providers, using shared decision-making processes and building core applications at the state level",
        "Wrapper": [
            {
                "Sub Groups": [
                    "Teamwork enhancement",
                    "Governance with Integrity",
                    "Process optimization"
                ],
                "Catergories": [
                    "Reporting Systems",
                    "Governance",
                    "Process Optimization"
                ],
                "Groups": [
                    "Collaboration and Communication",
                    "Policy and Organizational Reform",
                    "Operational Effectiveness and Efficiency"
                ],
                "Sub Catergories": [
                    "Business intelligence platforms, dashboard software, data visualization tools.",
                    "Policy management systems, compliance tracking, audit management tools.",
                    "Workflow engines, automation platforms, process mining tools."
                ],
                "Factors": [
                    "Collaboration & teamwork",
                    "Policy & governance reform",
                    "Standardization"
                ]
            }
        ]
    },
    {
        "ID": 55,
        "Extracts": "Applications and projects are categorized as core, common, or divergent, influencing their prioritization, funding, and management, with core ones managed by the Department, common ones collaboratively, and divergent ones allowing for innovative solutions to local needs.",
        "Wrapper": [
            {
                "Sub Groups": [
                    "Data governance",
                    "Strategic Cohesion",
                    "Responsive Support"
                ],
                "Catergories": [
                    "Policy Compliance",
                    "Governance Structure",
                    "Performance Tuning"
                ],
                "Groups": [
                    "Data and Information Management",
                    "Business Alignment",
                    "System Maintenance and Support"
                ],
                "Sub Catergories": [
                    "Automated compliance monitoring, reporting systems, risk assessment tools.",
                    "Organizational chart software, collaboration platforms, communication channels.",
                    "Monitoring tools, system optimization software, load balancers."
                ],
                "Factors": [
                    "Data management",
                    "Resource allocation",
                    "Performance monitoring"
                ]
            }
        ]
    },
    {
        "ID": 56,
        "Extracts": "The Project Governance framework makes sure projects do what they're supposed to and deliver the benefits they promised. It helps NSW Health focus on the right projects and ensures they're done correctly. This way, strategy and delivery stay connected, reducing risks for the whole portfolio",
        "Wrapper": [
            {
                "Sub Groups": [
                    "Strategic Cohesion",
                    "Accountable Risk Management",
                    "Strategic Cohesion"
                ],
                "Catergories": [
                    "Policy & Regulation",
                    "Joint Program Delivery",
                    "Policy & Regulation"
                ],
                "Groups": [
                    "Business Alignment",
                    "Risk Identification and Management",
                    "Business Alignment"
                ],
                "Sub Catergories": [
                    "Compliance management systems, policy repositories, audit tools.",
                    "Collaborative project management tools, communication platforms, shared resource pools.",
                    "Compliance management systems, policy repositories, audit tools."
                ],
                "Factors": [
                    "Strategic alignment",
                    "Risk identification & mitigation",
                    "Strategic alignment"
                ]
            }
        ]
    },
    {
        "ID": 57,
        "Extracts": "In the Content Development phase, they design and build a prototype, then review it with clinicians. We use a method called Fast Track, which makes the process quicker. The prototype helps clinicians understand the application better and decide if it works for them",
        "Wrapper": [
            {
                "Sub Groups": [
                    "Strategic Project Leadership",
                    "Reliable Implementation",
                    "Data governance"
                ],
                "Catergories": [
                    "Stakeholder Engagement",
                    "Change Initiatives",
                    "Change Readiness"
                ],
                "Groups": [
                    "Program and Project Management",
                    "System Deployment and Integration",
                    "Data and Information Management"
                ],
                "Sub Catergories": [
                    "Collaboration platforms, survey software, communication tools.",
                    "Change management software, communication platforms, project tracking tools.",
                    "Readiness assessment tools, survey platforms, stakeholder engagement systems."
                ],
                "Factors": [
                    "Project prioritization",
                    "Integration capabilities",
                    "Knowledge & content management"
                ]
            }
        ]
    },
    {
        "ID": 58,
        "Extracts": "In the Implementation phase, they're putting in the content decided by the state. Doing it all at once might seem like a lot, but it's the most efficient and cost-effective way. Using the Fast Track Method makes things quicker and cheaper, sticking to a standard design with state content. This means less hassle and less time spent learning for Area Health Services staff. Their team knows how to build the database, and doing things fast helps them stick to the plan without adding extra stuff.",
        "Wrapper": [
            {
                "Sub Groups": [
                    "Data governance",
                    "Strategic Cohesion",
                    "Employee development",
                    "Strategic Project Leadership"
                ],
                "Catergories": [
                    "Change Readiness",
                    "Governance Structure",
                    "Care Coordination Systems",
                    "Process Standardization"
                ],
                "Groups": [
                    "Data and Information Management",
                    "Business Alignment",
                    "Employee Training and Development",
                    "Program and Project Management"
                ],
                "Sub Catergories": [
                    "Readiness assessment tools, survey platforms, stakeholder engagement systems.",
                    "Organizational chart software, collaboration platforms, communication channels.",
                    "Patient management systems, health information exchanges, secure messaging platforms.",
                    "SOP management software, compliance tools, training platforms."
                ],
                "Factors": [
                    "Knowledge & content management",
                    "Resource allocation",
                    "Skills development",
                    "Scope management"
                ]
            }
        ]
    },
    {
        "ID": 59,
        "Extracts": "The SBB uses a maturity model to improve its features over time, with all Area Health Services contributing to each version, changes requiring approval from the majority of the Application Advisory Group, and new versions released annually, featuring required core functions, modifiable features, and local content.",
        "Wrapper": [
            {
                "Sub Groups": [
                    "Data governance",
                    "Strategic Project Leadership"
                ],
                "Catergories": [
                    "Organizational Value",
                    "Process Standardization"
                ],
                "Groups": [
                    "Data and Information Management",
                    "Program and Project Management"
                ],
                "Sub Catergories": [
                    "Performance measurement systems, value tracking tools, business intelligence.",
                    "SOP management software, compliance tools, training platforms."
                ],
                "Factors": [
                    "Inclusion & equity",
                    "Scope management"
                ]
            }
        ]
    },
    {
        "ID": 60,
        "Extracts": "The Clinical Systems Strategy aims to implement essential clinical systems supporting Clinical Services Redesign, Quality and Safety initiatives, and clinical programs. It focuses on improving communication, reducing delays, and supporting patient care, ensuring resources are allocated flexibly to meet patient needs",
        "Wrapper": [
            {
                "Sub Groups": [
                    "Strategic Cohesion",
                    "Strategic Project Leadership",
                    "Strategic Cohesion"
                ],
                "Catergories": [
                    "Policy & Regulation",
                    "Stakeholder Engagement",
                    "Governance Structure"
                ],
                "Groups": [
                    "Business Alignment",
                    "Program and Project Management",
                    "Business Alignment"
                ],
                "Sub Catergories": [
                    "Compliance management systems, policy repositories, audit tools.",
                    "Collaboration platforms, survey software, communication tools.",
                    "Organizational chart software, collaboration platforms, communication channels."
                ],
                "Factors": [
                    "Strategic alignment",
                    "Project prioritization",
                    "Resource allocation"
                ]
            }
        ]
    },
    {
        "ID": 61,
        "Extracts": "Three programs support the Clinical Systems Strategy: the Electronic Medical Record program for managing patients in hospitals, the Primary, Community, and Outpatient Care program for community care, and the Clinical Support program for essential support systems like Patient Administration and diagnostics.",
        "Wrapper": [
            {
                "Sub Groups": [
                    "Strategic Project Leadership",
                    "Reliable Implementation",
                    "Consistent Excellence"
                ],
                "Catergories": [
                    "Stakeholder Engagement",
                    "Change Initiatives",
                    "Standards Adherence"
                ],
                "Groups": [
                    "Program and Project Management",
                    "System Deployment and Integration",
                    "Standardization and Streamlining Processes"
                ],
                "Sub Catergories": [
                    "Collaboration platforms, survey software, communication tools.",
                    "Change management software, communication platforms, project tracking tools.",
                    "Code quality tools, compliance software, audit management systems."
                ],
                "Factors": [
                    "Project prioritization",
                    "Integration capabilities",
                    "System compatibility"
                ]
            }
        ]
    },
    {
        "ID": 62,
        "Extracts": "The Corporate Systems Strategy sets up essential systems to support the Corporate Shared Services reform program, cutting duplication and costs in administrative tasks to redirect funds to frontline care, with the Corporate Systems program as its backbone.",
        "Wrapper": [
            {
                "Sub Groups": [
                    "Reliable Implementation",
                    "Process optimization",
                    "Data integrity",
                    "Data integrity"
                ],
                "Catergories": [
                    "Change Initiatives",
                    "Application Categorization",
                    "Program Governance",
                    "Communication Tools"
                ],
                "Groups": [
                    "System Deployment and Integration",
                    "Operational Effectiveness and Efficiency",
                    "Data Security, Quality and Privacy",
                    "Data Security, Quality and Privacy"
                ],
                "Sub Catergories": [
                    "Change management software, communication platforms, project tracking tools.",
                    "Metadata repositories, CMDB systems, and application portfolio management tools.",
                    "Governance platforms, risk management tools, compliance dashboards.",
                    "Unified communications systems, VoIP, video conferencing platforms."
                ],
                "Factors": [
                    "Integration capabilities",
                    "Process efficiency",
                    "Data integrity & privacy",
                    "Secure data practices"
                ]
            }
        ]
    },
    {
        "ID": 63,
        "Extracts": "The Business Information Strategy aims to provide timely, high-quality information throughout the organization, fostering a performance-driven culture. It helps turn data into insights, supports decision-making, aligns with strategic goals, ensures accountability, and follows the overall program and change management approach.",
        "Wrapper": [
            {
                "Sub Groups": [
                    "Responsive Support",
                    "Data governance",
                    "Responsive Support",
                    "Reliable Implementation",
                    "Reliable Implementation",
                    "Data governance",
                    "Data integrity"
                ],
                "Catergories": [
                    "Performance Tuning",
                    "Policy Compliance",
                    "Performance Tuning",
                    "Change Initiatives",
                    "UX Design",
                    "Change Management",
                    "Program Governance"
                ],
                "Groups": [
                    "System Maintenance and Support",
                    "Data and Information Management",
                    "System Maintenance and Support",
                    "System Deployment and Integration",
                    "System Deployment and Integration",
                    "Data and Information Management",
                    "Data Security, Quality and Privacy"
                ],
                "Sub Catergories": [
                    "Monitoring tools, system optimization software, load balancers.",
                    "Automated compliance monitoring, reporting systems, risk assessment tools.",
                    "Monitoring tools, system optimization software, load balancers.",
                    "Change management software, communication platforms, project tracking tools.",
                    "Prototyping tools, user testing platforms, accessibility compliance software.",
                    "Collaboration tools, training portals, feedback and adoption tracking systems.",
                    "Governance platforms, risk management tools, compliance dashboards."
                ],
                "Factors": [
                    "Performance monitoring",
                    "Data management",
                    "Performance monitoring",
                    "Integration capabilities",
                    "Unified platforms",
                    "Data sharing & integration",
                    "Data integrity & privacy"
                ]
            }
        ]
    },
    {
        "ID": 64,
        "Extracts": "Three programs support the Business Information Strategy: one delivers useful information to front-line staff, another integrates strategic frameworks and develops performance measures, and the third ensures systems can provide consistent data and sets up technical infrastructure",
        "Wrapper": [
            {
                "Sub Groups": [
                    "Strategic Project Leadership",
                    "Strategic Cohesion",
                    "Responsive Support"
                ],
                "Catergories": [
                    "Stakeholder Engagement",
                    "Policy & Regulation",
                    "Performance Tuning"
                ],
                "Groups": [
                    "Program and Project Management",
                    "Business Alignment",
                    "System Maintenance and Support"
                ],
                "Sub Catergories": [
                    "Collaboration platforms, survey software, communication tools.",
                    "Compliance management systems, policy repositories, audit tools.",
                    "Monitoring tools, system optimization software, load balancers."
                ],
                "Factors": [
                    "Project prioritization",
                    "Strategic alignment",
                    "Performance monitoring"
                ]
            }
        ]
    },
    {
        "ID": 65,
        "Extracts": "The Sustainable Infrastructure program aims to streamline technical infrastructure, establish and uphold standards and architecture for statewide ICT initiatives, and ensure maximum benefit from ICT investments.",
        "Wrapper": [
            {
                "Sub Groups": [
                    "Sustainable Systems",
                    "Process optimization",
                    "Strategic Cohesion"
                ],
                "Catergories": [
                    "Financial Planning",
                    "Process Optimization",
                    "Governance Structure"
                ],
                "Groups": [
                    "Infrastructure and Hardware Management",
                    "Operational Effectiveness and Efficiency",
                    "Business Alignment"
                ],
                "Sub Catergories": [
                    "Budgeting software, forecasting models, financial dashboards.",
                    "Workflow engines, automation platforms, process mining tools.",
                    "Organizational chart software, collaboration platforms, communication channels."
                ],
                "Factors": [
                    "Infrastructure efficiency",
                    "Standardization",
                    "Resource allocation"
                ]
            }
        ]
    },
    {
        "ID": 66,
        "Extracts": "The Sustainable Infrastructure program includes three parts: setting up infrastructure, establishing technical standards, and ensuring uniform data standards across systems in NSW.",
        "Wrapper": [
            {
                "Sub Groups": [
                    "Sustainable Systems",
                    "Process optimization",
                    "Data integrity"
                ],
                "Catergories": [
                    "Financial Planning",
                    "Process Optimization",
                    "Program Governance"
                ],
                "Groups": [
                    "Infrastructure and Hardware Management",
                    "Operational Effectiveness and Efficiency",
                    "Data Security, Quality and Privacy"
                ],
                "Sub Catergories": [
                    "Budgeting software, forecasting models, financial dashboards.",
                    "Workflow engines, automation platforms, process mining tools.",
                    "Governance platforms, risk management tools, compliance dashboards."
                ],
                "Factors": [
                    "Infrastructure efficiency",
                    "Standardization",
                    "Data integrity & privacy"
                ]
            }
        ]
    }
];