import os
import subprocess
from shutil import which

def check_account(expected_user="standard"):
    """Check if the script is run as the expected user: 'standard' or 'root'."""
    is_root = os.geteuid() == 0
    expected_user = expected_user.lower()

    if expected_user == "standard" and is_root:
        print("Please run this script as a standard (non-root) user.")
        return False
    elif expected_user == "root" and not is_root:
        print("Please run this script as root.")
        return False
    return True

def get_model():
    """Get computer model using dmidecode."""
    try:
        output = subprocess.check_output(["sudo", "dmidecode", "-s", "system-product-name"])
        return output.decode().strip().replace(" ", "")
    except subprocess.CalledProcessError:
        return "default"

def ensure_dependencies_installed(dependencies):
    """Ensure all required external dependencies are installed."""
    for dep in dependencies:
        if which(dep) is None:
            print(f"{dep} not found. Attempting to install.")
            subprocess.run(["sudo", "apt", "update", "-y"], check=True)
            subprocess.run(["sudo", "apt", "install", "-y", dep], check=True)
