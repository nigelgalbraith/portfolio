import json

def get_value_from_json(config_path, model, key):
    """Returns value for model-specific key from a JSON config, falling back to 'default'."""
    with open(config_path) as f:
        config = json.load(f)
    return config.get(model, {}).get(key) or config.get("default", {}).get(key)

def get_list_from_json(json_file, model, key):
    """Extracts a list of values from a JSON file using model and key, or falls back to default."""
    with open(json_file) as f:
        data = json.load(f)
    return data.get(model, {}).get(key, []) or data.get("default", {}).get(key, [])

def get_json_keys(json_path, top_key, block_key):
    """Get all top-level keys from a JSON config."""
    with open(json_path) as f:
        data = json.load(f)
    return list(data.get(top_key, {}).get(block_key, {}).keys())

def get_indexed_field_list(json_file, model, block, index, field):
    """Get a list from a JSON array block at a given index and field."""
    with open(json_file) as f:
        data = json.load(f)
    return data.get(model, {}).get(block, [{}])[index].get(field, [])

def build_indexed_jobs(json_path, model, block, fields):
    """Build a job dict indexed by position with selected fields."""
    with open(json_path) as f:
        data = json.load(f)
    jobs = {}
    for i, entry in enumerate(data.get(model, {}).get(block, [])):
        jobs[i] = {field: entry.get(field, "") for field in fields}
    return jobs

def filter_jobs_by_status(status_dict, desired_status, json_data, model, block_name, fields):
    """Filters items by status and returns a dictionary of jobs with selected fields from a JSON block."""
    item_block = json_data.get(model, {}).get(block_name, {}) or json_data.get("default", {}).get(block_name, {})
    jobs = {}
    for item, status in status_dict.items():
        if status == desired_status:
            job_entry = {field: " ".join(item_block.get(item, {}).get(field, []))
                         if isinstance(item_block.get(item, {}).get(field), list)
                         else item_block.get(item, {}).get(field)
                         for field in fields}
            jobs[item] = job_entry
    return jobs
