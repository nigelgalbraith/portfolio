import subprocess
import json

def allow_application(app):
    """Allow UFW app profile."""
    out = subprocess.run(["ufw", "app", "list"], capture_output=True, text=True)
    if app in out.stdout:
        return subprocess.run(["ufw", "allow", app], capture_output=True, text=True).stdout
    return f"Application profile '{app}' not found."

def allow_port(port, proto):
    """Allow any port/proto."""
    return subprocess.run(["ufw", "allow", f"{port}/{proto}"], capture_output=True, text=True).stdout

def allow_port_for_ip(port, proto, ip):
    """Allow port from specific IP."""
    return subprocess.run(
        ["ufw", "allow", "proto", proto, "from", ip, "to", "any", "port", str(port)],
        capture_output=True, text=True
    ).stdout

def allow_port_range_for_ip(start, end, proto, ip):
    """Allow port range from specific IP."""
    return subprocess.run(
        ["ufw", "allow", "proto", proto, "from", ip, "to", "any", "port", f"{start}:{end}"],
        capture_output=True, text=True
    ).stdout

