def format_status_summary(status_dict, label="Item", count_keys=None):
    """ Returns a formatted summary of statuses in a dictionary, with counts. """
    lines = []
    lines.append(f"\n{label} Status Summary\n" + "-" * (len(label) + 16))
    lines.append(f"{label:<30}Status")
    lines.append(f"{'-' * len(label):<30}------")

    for item, status in status_dict.items():
        lines.append(f"{item:<30}{status}")

    # Count occurrences
    counts = {}
    for status in status_dict.values():
        counts[status] = counts.get(status, 0) + 1

    lines.append("\nSummary:\n--------")
    display_keys = count_keys if count_keys else sorted(counts.keys())
    for key in display_keys:
        lines.append(f"{key:<13}: {counts.get(key, 0)}")
    lines.append(f"Total        : {sum(counts.values())}")
    return "\n".join(lines)

def print_dict_table(items, field_names, label):
    """Prints a table for a list of dictionaries."""
    if not items:
        print(f"\n{label.upper()}: (None)")
        return

    print(f"\n{label.upper()}:")
    col_widths = [max(len(field), 12) for field in field_names]

    # Header
    print("  " + "  ".join(f"{field:<{col_widths[i]}}" for i, field in enumerate(field_names)))
    print("  " + "  ".join("-" * col_widths[i] for i in range(len(field_names))))

    # Rows
    for item in items:
        print("  " + "  ".join(f"{str(item.get(field, '')):<{col_widths[i]}}" for i, field in enumerate(field_names)))


def print_list_section(items, label):
    """Prints a flat list of strings under a label."""
    print(f"\n{label.upper()}:")
    for item in items:
        print(f"  - {item}")
