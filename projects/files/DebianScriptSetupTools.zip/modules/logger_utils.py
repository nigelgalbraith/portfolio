import logging

def setup_logging(log_file, log_dir):
    """Configure the logging system."""
    log_dir.mkdir(parents=True, exist_ok=True)
    logging.basicConfig(
        filename=log_file,
        level=logging.INFO,
        format='%(asctime)s %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S'
    )

def log_and_print(message):
    """Logs a message and prints it to terminal."""
    print(message)
    logging.info(message)

def rotate_logs(log_dir, logs_to_keep, pattern="*.log"):
    """Deletes oldest log files matching pattern if count exceeds limit."""
    logs = sorted(log_dir.glob(pattern), key=lambda f: f.stat().st_mtime)
    for old_log in logs[:-logs_to_keep]:
        old_log.unlink()
        print(f"Deleted old log: {old_log}")

