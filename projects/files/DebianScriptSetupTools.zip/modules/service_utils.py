import subprocess
import os
from pathlib import Path
from modules.logger_utils import log_and_print
from shutil import copyfile

def check_service_status(service_name):
    """Check if a systemd service is enabled."""
    result = subprocess.run(["systemctl", "is-enabled", service_name], stdout=subprocess.PIPE)
    return "ENABLED" if result.returncode == 0 else "DISABLED"

def copy_template(src, dest):
    """Copy a script to the destination and make it executable."""
    subprocess.run(["cp", src, dest], check=True)
    subprocess.run(["chmod", "+x", dest], check=True)
    log_and_print(f"Copied script: {src} → {dest}")

def create_service(src, dest):
    """Copy and register a systemd service unit file."""
    subprocess.run(["cp", src, dest], check=True)
    subprocess.run(["systemctl", "daemon-reload"], check=True)
    log_and_print(f"Created service: {src} → {dest}")

def enable_and_start_service(service_name):
    """Enable and start a systemd service."""
    subprocess.run(["systemctl", "enable", service_name], check=True)
    subprocess.run(["systemctl", "start", service_name], check=True)
    log_and_print(f"Enabled and started: {service_name}")

def stop_and_disable_service(service_name):
    """Stop and disable a systemd service."""
    subprocess.run(["systemctl", "stop", service_name], check=True)
    subprocess.run(["systemctl", "disable", service_name], check=True)
    log_and_print(f"Stopped and disabled: {service_name}")

def remove_path(path):
    """Delete a file or symbolic path."""
    Path(path).unlink(missing_ok=True)
    log_and_print(f"Removed: {path}")

def show_logs(path):
    """Display the contents of a log file."""
    print(f"\n--- Logs: {path} ---")
    if Path(path).exists():
        with open(path) as f:
            print(f.read())
    else:
        print("Log file does not exist.")

def install_logrotate_config(template_path, target_name, target_dir="/etc/logrotate.d"):
    """Copy a static logrotate config to /etc/logrotate.d/."""
    dest_path = Path(target_dir) / target_name
    copyfile(template_path, dest_path)
    os.chmod(dest_path, 0o644)
    log_and_print(f"Installed logrotate config: {dest_path}")

