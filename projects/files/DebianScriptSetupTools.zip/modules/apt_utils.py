import subprocess
from pathlib import Path
import json

def conflicting_repo_entry_exists(url, keyring):
    """Check if any existing repo for the URL uses a conflicting signed-by keyring."""
    list_dir = Path("/etc/apt/sources.list.d")
    for list_file in list_dir.glob("*.list"):
        with open(list_file, "r") as f:
            for line in f:
                if url in line and "signed-by" in line and keyring not in line:
                    return True
    return False

def add_apt_repository(name, url, key_urls, codename, component):
    """Add an APT repository and its GPG key(s) if not already added."""
    repo_file = Path(f"/etc/apt/sources.list.d/{name}.list")
    keyring_file = Path(f"/usr/share/keyrings/{name}.gpg")

    if repo_file.exists():
        print(f"Repo file already exists: {repo_file}")
        return

    if not keyring_file.exists():
        keys = json.loads(key_urls) if key_urls.startswith("[") else [key_urls]
        for key_url in keys:
            result = subprocess.run(
                f"curl -fsSL {key_url} | gpg --dearmor | sudo tee -a {keyring_file}",
                shell=True
            )
            if result.returncode != 0:
                print(f"Failed to fetch key from {key_url}")
                return

    entry = f"deb [arch=amd64 signed-by={keyring_file}] {url} {codename} {component}"
    subprocess.run(f"echo '{entry}' | sudo tee {repo_file}", shell=True)

def remove_apt_repo_and_keyring(name):
    """Remove the APT source list and GPG key for a given repo name using sudo."""
    repo_file = Path(f"/etc/apt/sources.list.d/{name}.list")
    keyring_file = Path(f"/usr/share/keyrings/{name}.gpg")

    if repo_file.exists():
        subprocess.run(["sudo", "rm", str(repo_file)], check=True)
        print(f"Removed APT source file: {repo_file}")
    if keyring_file.exists():
        subprocess.run(["sudo", "rm", str(keyring_file)], check=True)
        print(f"Removed GPG keyring: {keyring_file}")
