import subprocess
from pathlib import Path

def check_package(pkg):
    """Check if a package is installed using dpkg-query."""
    try:
        output = subprocess.check_output(["dpkg-query", "-W", "-f=${Status}", pkg])
        if b"install ok installed" in output:
            return "INSTALLED"
    except subprocess.CalledProcessError:
        pass
    return "NOT INSTALLED"

def filter_by_status(items: dict, match_statuses: list | str) -> list:
    """Returns item names where the status matches the given value or list of values."""
    if isinstance(match_statuses, str):
        match_statuses = [match_statuses]
    return [name for name, status in items.items() if status in match_statuses]

def install_packages(packages):
    """Install missing packages."""
    if not packages:
        return
    subprocess.run(["sudo", "apt", "update", "-y"], check=True)
    subprocess.run(["sudo", "apt", "install", "-y"] + packages, check=True)

def uninstall_packages(packages):
    """Uninstall listed packages."""
    if not packages:
        return
    subprocess.run(["sudo", "apt", "remove", "-y"] + packages, check=True)
    subprocess.run(["sudo", "apt", "autoremove", "-y"], check=True)

def download_deb_file(pkg, url, download_dir):
    """Download a DEB file from a given URL into the specified directory."""
    download_dir.mkdir(parents=True, exist_ok=True)
    dest = download_dir / f"{pkg}.deb"
    print(f"Downloading {pkg} from {url}")
    result = subprocess.run(["wget", "-q", "--show-progress", "-O", str(dest), url])
    return dest if result.returncode == 0 else None

def install_deb_file(deb_file, name):
    """Install a DEB file and fix dependencies if needed."""
    print(f"Installing {name} from {deb_file}")
    if subprocess.run(["sudo", "dpkg", "-i", str(deb_file)]).returncode != 0:
        subprocess.run(["sudo", "apt-get", "install", "-f", "-y"], check=True)
        if subprocess.run(["sudo", "dpkg", "-i", str(deb_file)]).returncode != 0:
            print(f"Retry install failed for {name}")
            return False
    return True

def uninstall_deb_package(name):
    """Uninstall a DEB package and purge configuration."""
    print(f"Uninstalling {name}")
    result = subprocess.run(["sudo", "apt-get", "remove", "--purge", "-y", name])
    if result.returncode == 0:
        subprocess.run(["sudo", "apt-get", "autoremove", "-y"], check=True)
        return True
    return False

def start_service_if_enabled(enable_flag, service):
    """Enable and start a service if the flag is true."""
    if enable_flag == "true" and service:
        print(f"Starting service: {service}")
        subprocess.run(["sudo", "systemctl", "enable", service])
        subprocess.run(["sudo", "systemctl", "start", service])

