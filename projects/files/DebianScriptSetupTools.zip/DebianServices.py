#!/usr/bin/env python3

import os
import json
from pathlib import Path
import datetime

from modules.logger_utils import setup_logging, log_and_print, rotate_logs
from modules.system_utils import check_account, get_model, ensure_dependencies_installed
from modules.json_utils import get_json_keys, get_value_from_json, filter_jobs_by_status
from modules.summary_utils import format_status_summary
from modules.service_utils import (
    check_service_status,
    copy_template,
    create_service,
    enable_and_start_service,
    stop_and_disable_service,
    remove_path,
    show_logs,
    install_logrotate_config
)

# === CONSTANTS ===
PRIMARY_CONFIG = "config/AppConfigSettings.json"
SERVICE_KEY = "Services"
LOG_DIR = Path.home() / "logs" / "services"
TIMESTAMP = datetime.datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
LOG_FILE = LOG_DIR / f"services_install_{TIMESTAMP}.log"
LOGS_TO_KEEP = 10
LOG_PER = 0o755
ROTATE_LOG_NAME="services_install_{.log"
DEPENDENCIES = ["logrotate"]
REQUIRED_USER = "root"
SUMMARY_LABEL = "Service"
FIELDS = [
    "ScriptSrc", "ScriptDest", "ServiceSrc",
    "ServiceDest", "ServiceName", "LogPath", "LogrotateCfg"
]


def main():
    """Main logic to setup, remove, or display service logs."""

    # Setup logging
    setup_logging(LOG_FILE, LOG_DIR)

    # Check required user
    if not check_account(REQUIRED_USER):
        return

    # Ensure all CLI dependencies exist
    ensure_dependencies_installed(DEPENDENCIES)

    # Identify current system model
    model = get_model()
    log_and_print(f"Detected model: {model}")

    # Load config path for this model
    services_file = get_value_from_json(PRIMARY_CONFIG, model, SERVICE_KEY)
    if not services_file or not Path(services_file).exists():
        log_and_print(f"No services config file found for model '{model}'.")
        return

    log_and_print(f"Using service config file: {services_file}")
    service_keys = get_json_keys(services_file, model, SERVICE_KEY)
    if not service_keys:
        log_and_print("No services found.")
        return

    # Check service status (ENABLED/DISABLED)
    service_status = {}
    with open(services_file) as f:
        data = json.load(f)
        for key in service_keys:
            service_name = data.get(model, {}).get(SERVICE_KEY, {}).get(key, {}).get("ServiceName")
            if service_name:
                service_status[key] = check_service_status(service_name)

    # Display status summary
    log_and_print("\n" + format_status_summary(service_status, label=SUMMARY_LABEL, count_keys=["ENABLED", "DISABLED"]))

    # Prompt for action
    print("\nChoose an option:")
    print("1) Setup services")
    print("2) Remove services")
    print("3) Show logs")
    print("4) Exit")
    choice = input("Selection (1/2/3/4): ").strip()

    if choice == "4":
        log_and_print("Exited by user.")
        return

    action = "install" if choice == "1" else "uninstall" if choice == "2" else "logs"

    # Build job list based on selected action
    with open(services_file) as f:
        services_data = json.load(f)

    jobs = filter_jobs_by_status(
        service_status,
        "DISABLED" if action == "install" else "ENABLED" if action == "uninstall" else "ALL",
        services_data,
        model,
        SERVICE_KEY,
        FIELDS
    )

    # Execute job actions
    for key, meta in jobs.items():
        if action == "install":
            if "LogrotateCfg" in meta:
                target_name = Path(meta["LogrotateCfg"]).stem 
                install_logrotate_config(meta["LogrotateCfg"], target_name)
            copy_template(meta["ScriptSrc"], meta["ScriptDest"])
            create_service(meta["ServiceSrc"], meta["ServiceDest"])
            enable_and_start_service(meta["ServiceName"])
            Path(meta["LogPath"]).touch(mode=0o644, exist_ok=True) 

        elif action == "uninstall":
            stop_and_disable_service(meta["ServiceName"])
            remove_path(meta["ServiceDest"])
            remove_path(meta["ScriptDest"])
        elif action == "logs":
            for key, meta in jobs.items():
                if "LogPath" in meta:
                    show_logs(meta["LogPath"])


    # Set log dir permissions and rotate old logs
    os.chmod(LOG_DIR, LOG_PER)
    rotate_logs(LOG_DIR, LOGS_TO_KEEP, ROTATE_LOG_NAME)
    log_and_print(f"\nAll actions complete. Log: {LOG_FILE}")


if __name__ == "__main__":
    main()
