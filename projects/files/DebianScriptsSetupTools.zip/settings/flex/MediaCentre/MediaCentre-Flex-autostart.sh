#!/bin/bash
flex-launcher &
